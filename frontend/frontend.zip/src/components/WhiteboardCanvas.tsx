import { useState, useRef, useEffect } from 'react';
import { Stage, Layer, Line, Image as KonvaImage } from 'react-konva';
import { useParams, useNavigate } from 'react-router-dom';
import { jsPDF } from 'jspdf';
import keycloak from '../keycloak';
import ChatPanel from './ChatPanel';
import CollaboratorInvite from './CollaboratorInvite';
import { Socket } from 'socket.io-client';
import { createAuthenticatedSocket } from '../lib/socketUtils';
import { KonvaEventObject } from 'konva/lib/Node';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Pencil, Eraser, Trash2, Upload, Download, FileDown, ArrowLeft } from 'lucide-react';
import { cn } from '../lib/utils';

interface LineProps {
  tool: string;
  points: number[];
  color: string;
  strokeWidth: number;
}

interface ImageProps {
  x: number;
  y: number;
  width: number;
  height: number;
  src: string;
}

interface ActiveUser {
  userId: string;
  username: string;
}

const WhiteboardCanvas = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const stageRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [lines, setLines] = useState<LineProps[]>([]);
  const [images, setImages] = useState<ImageProps[]>([]);
  const [color, setColor] = useState<string>('#000000');
  const [strokeWidth, setStrokeWidth] = useState<number>(5);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [isCreator, setIsCreator] = useState<boolean>(false);
  const [boardTitle, setBoardTitle] = useState<string>('Whiteboard');
  const [socket, setSocket] = useState<Socket | null>(null);
  const [stageSize, setStageSize] = useState({ width: window.innerWidth * 0.9, height: window.innerHeight * 0.7 });
  const [activeUsers, setActiveUsers] = useState<ActiveUser[]>([]);
  
  // Initialize socket connection
  useEffect(() => {
    if (!id) return;
    
    const initSocket = async () => {
      try {
        const socketInstance = await createAuthenticatedSocket();
    setSocket(socketInstance);
    
      socketInstance.emit('join-room', id);
    
    // Listen for active users
    socketInstance.on('user-joined', (data) => {
      console.log('User joined:', data);
      setActiveUsers(prevUsers => {
        // Only add if not already in the list
        if (!prevUsers.some(user => user.userId === data.userId)) {
          return [...prevUsers, { userId: data.userId, username: data.username }];
        }
        return prevUsers;
      });
    });
    
    socketInstance.on('user-left', (data) => {
      console.log('User left:', data);
      setActiveUsers(prevUsers => prevUsers.filter(user => user.userId !== data.userId));
    });
    
    socketInstance.on('room-info', (data) => {
      console.log('Room info received:', data);
    });
    
    // Listen for draw events from other users
    socketInstance.on('draw', (data) => {
      console.log('Received drawing update:', data);
      setLines(prevLines => {
        // Find the line with the matching lineId or add a new one
        const newLines = [...prevLines];
        if (data.isNewLine) {
          newLines.push(data.line);
        } else {
          // Update existing line
          const index = newLines.findIndex(line => 
            line.points[0] === data.line.points[0] && 
            line.points[1] === data.line.points[1]
          );
          if (index !== -1) {
            newLines[index] = data.line;
          }
        }
        return newLines;
      });
    });
    
    // Listen for image added by other users
    socketInstance.on('add-image', (data) => {
      console.log('Received new image:', data);
      setImages(prevImages => [...prevImages, data.image]);
    });
    
    return () => {
      socketInstance.disconnect();
    };
      } catch (error) {
        console.error('Failed to initialize socket:', error);
      }
    };
    
    initSocket();
  }, [id]);
  
  // Listen for window resize to adjust stage size
  useEffect(() => {
    const handleResize = () => {
      setStageSize({
        width: window.innerWidth * 0.9,
        height: window.innerHeight * 0.7
      });
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Fetch whiteboard data
  useEffect(() => {
    if (!id) return;
    
    const username = keycloak.tokenParsed?.preferred_username;
    console.log("Current user:", username);
    
    // Check if we are the creator and get whiteboard data
    const fetchWhiteboard = async () => {
      try {
        const token = keycloak.token;
        if (!token) return;
        
        console.log("Fetching whiteboard data...");
        const res = await fetch(`http://localhost:4000/whiteboards/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.ok) {
          const data = await res.json();
          console.log("Whiteboard data:", data);
          
          setBoardTitle(data.title || 'Whiteboard');
          
          // Check if user is the creator
          if (data.created_by === username) {
            console.log("User is the creator!");
            setIsCreator(true);
          }
          
          if (data.content && data.content.elements && Array.isArray(data.content.elements)) {
            setLines(data.content.elements);
          }
          
          if (data.content && data.content.images && Array.isArray(data.content.images)) {
            setImages(data.content.images);
          }
          
          setLoading(false);
        } else if (res.status === 403) {
          console.error("No access permission");
          alert('You do not have access to this whiteboard');
          navigate('/');
        } else {
          console.error("Failed to fetch whiteboard:", await res.text());
          setLoading(false);
        }
      } catch (err) {
        console.error("Error fetching whiteboard:", err);
        setLoading(false);
      }
    };
    
    fetchWhiteboard();
  }, [id, navigate]);
  
  const handleMouseDown = (e: KonvaEventObject<MouseEvent>) => {
    // Get pointer position from stage
    const stage = stageRef.current;
    if (!stage) return;
    
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;
    
    // Check if within boundaries
    if (pointerPos.x < 0 || pointerPos.y < 0 || 
        pointerPos.x > stage.width() || pointerPos.y > stage.height()) {
      return;
    }

    setIsDrawing(true);
    
    const newLines = [...lines];
    const newLine = {
      tool,
      points: [pointerPos.x, pointerPos.y],
      color: color,
      strokeWidth: strokeWidth,
    };
    newLines.push(newLine);
    
    setLines(newLines);
    
    // Send to server
    if (socket && socket.connected) {
      socket.emit('draw', { 
        roomId: id, 
        line: newLine,
        isNewLine: true
      });
    }
  };
  
  const handleMouseMove = (e: KonvaEventObject<MouseEvent>) => {
    if (!isDrawing) return;
    
    const stage = stageRef.current;
    if (!stage) return;
    
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;
    
    // Check if within boundaries
    if (pointerPos.x < 0 || pointerPos.y < 0 || 
        pointerPos.x > stage.width() || pointerPos.y > stage.height()) {
      // Instead of stopping drawing, just don't add the point outside boundaries
      return;
    }
    
    const newLines = [...lines];
    const lastLine = newLines[newLines.length - 1];
    
    // Add point to the last line
    lastLine.points = lastLine.points.concat([pointerPos.x, pointerPos.y]);
    setLines(newLines);
    
    // Send to server
    if (socket && socket.connected) {
      socket.emit('draw', { 
        roomId: id, 
        line: lastLine, 
        isNewLine: false 
      });
    }
  };
  
  const handleMouseUp = () => {
    setIsDrawing(false);
  };
  
  const clearCanvas = () => {
    setLines([]);
    setImages([]);
  };
  
  const exportAsImage = () => {
    if (!stageRef.current) return;
    
    const uri = stageRef.current.toDataURL();
    const link = document.createElement('a');
    link.download = `${boardTitle.replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = uri;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const exportAsPDF = () => {
    if (!stageRef.current) return;
    
    const uri = stageRef.current.toDataURL();
    const pdf = new jsPDF();
    
    // Calculate aspect ratio
    const imgWidth = pdf.internal.pageSize.getWidth();
    const imgHeight = (stageSize.height * imgWidth) / stageSize.width;
    
    pdf.addImage(uri, 'PNG', 0, 0, imgWidth, imgHeight);
    pdf.save(`${boardTitle.replace(/\s+/g, '-').toLowerCase()}.pdf`);
  };
  
  const handleImageUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    const reader = new FileReader();
    
    reader.onload = (event) => {
      if (!event.target) return;
      const result = event.target.result;
      if (typeof result !== 'string') return;
      
      const img = new window.Image();
      img.src = result;
      
      img.onload = () => {
        const stage = stageRef.current;
        if (!stage) return;
        
        const stageSize = stage.getSize();
        
        // Calculate dimensions to fit the image within the canvas while maintaining aspect ratio
        let width = img.width;
        let height = img.height;
        const maxWidth = stageSize.width * 0.8;
        const maxHeight = stageSize.height * 0.8;
        
        if (width > maxWidth) {
          const ratio = maxWidth / width;
          width = maxWidth;
          height = height * ratio;
        }
        
        if (height > maxHeight) {
          const ratio = maxHeight / height;
          height = maxHeight;
          width = width * ratio;
        }
        
        // Position the image in the center of the canvas
        const x = (stageSize.width - width) / 2;
        const y = (stageSize.height - height) / 2;
        
        const newImage: ImageProps = {
          x,
          y,
          width,
          height,
          src: result
        };
        
        setImages([...images, newImage]);
        
        // Emit to other users if socket exists
        if (socket && id) {
          socket.emit('add-image', {
            roomId: id,
            image: newImage
          });
        }
      };
    };
    
    reader.readAsDataURL(file);
    
    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  useEffect(() => {
    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, []);

  // Add global event listeners for mouse up and touch end
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      if (isDrawing) {
        setIsDrawing(false);
      }
    };

    // Add event listeners to document
    document.addEventListener('mouseup', handleGlobalMouseUp);
    document.addEventListener('touchend', handleGlobalMouseUp);

    // Clean up
    return () => {
      document.removeEventListener('mouseup', handleGlobalMouseUp);
      document.removeEventListener('touchend', handleGlobalMouseUp);
    };
  }, [isDrawing]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          <p className="text-lg text-muted-foreground">Loading whiteboard...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container p-4 mx-auto space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CardTitle className="text-2xl font-bold">{boardTitle}</CardTitle>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${isCreator ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                {isCreator ? 'Owner' : 'Collaborator'}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/')} className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </div>
        </CardHeader>
      </Card>
      
      {/* Active Users Section */}
      <Card className="bg-card/50 border-none shadow-sm">
        <CardContent className="p-4">
          <h3 className="text-sm font-medium mb-2">Active Users</h3>
          <div className="flex flex-wrap gap-2">
            {activeUsers.length > 0 ? (
              activeUsers.map((user) => (
                <span 
                  key={user.userId} 
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  title={user.username}
                >
                  {user.username}
                </span>
              ))
            ) : (
              <span className="text-sm text-muted-foreground">No other users currently active</span>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Tools Section */}
      <div className="flex flex-wrap gap-4 items-center">
        <div className="flex space-x-2">
          <Button
            variant={tool === 'pen' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTool('pen')}
            className="flex items-center gap-1"
          >
            <Pencil className="h-4 w-4" />
            Pen
          </Button>
          <Button
            variant={tool === 'eraser' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTool('eraser')}
            className="flex items-center gap-1"
          >
            <Eraser className="h-4 w-4" />
            Eraser
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={clearCanvas}
            className="flex items-center gap-1"
          >
            <Trash2 className="h-4 w-4" />
            Clear
          </Button>
        </div>
        
        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium">Color:</label>
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="w-8 h-8 p-0 border rounded cursor-pointer"
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium">Size:</label>
          <input
            type="range"
            min="1"
            max="50"
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(parseInt(e.target.value))}
            className="w-24 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={handleImageUpload}
          className="flex items-center gap-1"
        >
          <Upload className="h-4 w-4" />
          Add Image
        </Button>
        
        <div className="flex ml-auto space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={exportAsImage}
            className="flex items-center gap-1"
          >
            <Download className="h-4 w-4" />
            Export PNG
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={exportAsPDF}
            className="flex items-center gap-1"
          >
            <FileDown className="h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-9">
          <Card className="overflow-hidden border-none shadow-md">
            <div className="bg-white rounded-lg">
              <Stage
                width={stageSize.width}
                height={stageSize.height}
                onMouseDown={handleMouseDown}
                onMousemove={handleMouseMove}
                onMouseup={handleMouseUp}
                onMouseleave={handleMouseUp}
                ref={stageRef}
                style={{ 
                  backgroundColor: 'white',
                  cursor: 'crosshair',
                  touchAction: 'none',
                  display: 'block',
                  borderRadius: '8px'
                }}
              >
                <Layer>
                  {images.map((img, i) => (
                    <KonvaImage
                      key={`img-${i}`}
                      x={img.x}
                      y={img.y}
                      width={img.width}
                      height={img.height}
                      image={(() => {
                        const imgElement = new window.Image();
                        imgElement.src = img.src;
                        return imgElement;
                      })()}
                      draggable={true}
                    />
                  ))}
                  {lines.map((line, i) => (
                    <Line
                      key={i}
                      points={line.points}
                      stroke={line.color}
                      strokeWidth={line.strokeWidth}
                      tension={0.5}
                      lineCap="round"
                      lineJoin="round"
                      globalCompositeOperation={
                        line.tool === 'eraser' ? 'destination-out' : 'source-over'
                      }
                    />
                  ))}
                </Layer>
              </Stage>
            </div>
          </Card>
        </div>
        
        <div className="col-span-3">
          <Card className="h-full border-none shadow-sm">
            <CardContent className="p-4">
              {isCreator && (
                <CollaboratorInvite whiteboardId={id} />
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Capture any mouse up events that occur outside the stage */}
      <div 
        style={{ display: 'none' }}
        onMouseUp={handleMouseUp}
      />
      
      {/* Hidden file input for image uploads */}
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        accept="image/*"
        onChange={handleFileChange}
      />
      
      {/* Chat Panel */}
      <Card className="mt-4 border-none shadow-sm">
        <CardContent className="p-4">
          <ChatPanel socket={socket} roomId={id} />
        </CardContent>
      </Card>
    </div>
  );
};

export default WhiteboardCanvas; 