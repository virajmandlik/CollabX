import { useEffect, useState } from 'react';
import keycloak from './keycloak';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { FaPlus, FaPencilAlt, FaTrash, FaDownload } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { useNavigate } from 'react-router-dom';
import NotificationCenter from './components/NotificationCenter';

interface Whiteboard {
  id: number;
  title: string;
  content: {
    elements: any[];
  };
  created_at: string;
}

function App() {
  const [whiteboards, setWhiteboards] = useState<Whiteboard[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newBoardTitle, setNewBoardTitle] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [boardToDelete, setBoardToDelete] = useState<number | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchWhiteboards();
  }, []);

  const fetchWhiteboards = async () => {
    try {
      // Refresh token if needed
      try {
        await keycloak.updateToken(70);
      } catch (error) {
        console.error('Failed to refresh token:', error);
        keycloak.login();
        return;
      }
      
      const token = keycloak.token;
      if (!token) {
        console.error("No token available");
        return;
      }

      console.log("Fetching whiteboards with token...");
      const res = await fetch('http://localhost:4000/whiteboards', {
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("❌ Fetch whiteboards failed:", text);
        return;
      }

      const data = await res.json();
      setWhiteboards(data);
    } catch (err) {
      console.error("❌ fetchWhiteboards() error:", err);
    }
  };

  // Add token refresh handling
  useEffect(() => {
    const refreshToken = async () => {
      try {
        const refreshed = await keycloak.updateToken(70);
        if (refreshed) {
          console.log('Token refreshed');
        }
      } catch (error) {
        console.error('Failed to refresh token:', error);
        keycloak.login();
      }
    };

    refreshToken();
    const interval = setInterval(refreshToken, 60000); // Refresh every minute

    return () => clearInterval(interval);
  }, []);

  const createWhiteboard = async () => {
    try {
      const token = keycloak.token;
      const res = await fetch('http://localhost:4000/whiteboards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: newBoardTitle || 'New Board',
          content: { elements: [] },
        }),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("❌ Create whiteboard failed:", text);
        return;
      }

      const data = await res.json();
      setWhiteboards(prev => [...prev, data]);
      setShowCreateModal(false);
      setNewBoardTitle('');
    } catch (err) {
      console.error("❌ createWhiteboard() error:", err);
    }
  };

  const handleEditBoard = (id: number) => {
    navigate(`/whiteboard/${id}`);
  };

  const handleDeleteBoard = (id: number) => {
    setBoardToDelete(id);
    setShowDeleteModal(true);
  };

  const confirmDeleteBoard = async () => {
    if (!boardToDelete) return;
    
    try {
      // Refresh token if needed
      try {
        await keycloak.updateToken(70);
      } catch (error) {
        console.error('Failed to refresh token:', error);
        keycloak.login();
        return;
      }
      
      const token = keycloak.token;
      console.log(`Attempting to delete whiteboard ${boardToDelete}...`);
      
      const res = await fetch(`http://localhost:4000/whiteboards/${boardToDelete}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("❌ Delete whiteboard failed:", text);
        alert(`Failed to delete whiteboard: ${text}`);
        return;
      }

      console.log(`Whiteboard ${boardToDelete} deleted successfully`);
      setWhiteboards(prev => prev.filter(board => board.id !== boardToDelete));
      setShowDeleteModal(false);
      setBoardToDelete(null);
    } catch (err) {
      console.error("❌ deleteWhiteboard() error:", err);
      alert("Failed to delete whiteboard. Please try again.");
    }
  };

  const handleExportBoard = async (id: number) => {
    try {
      const token = keycloak.token;
      const res = await fetch(`http://localhost:4000/whiteboards/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("❌ Fetch whiteboard for export failed:", text);
        return;
      }

      const board = await res.json();
      const dataStr = JSON.stringify(board, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportName = `whiteboard-${board.id}-${board.title.replace(/\s+/g, '-').toLowerCase()}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportName);
      linkElement.click();
    } catch (err) {
      console.error("❌ exportWhiteboard() error:", err);
    }
  };

  return (
    <Container fluid className="p-4">
      <nav className="navbar navbar-dark bg-primary mb-4 px-3">
        <span className="navbar-brand">Collaborative Whiteboard</span>
        <div className="d-flex align-items-center">
          <NotificationCenter />
          <span className="text-light me-3">Welcome, {keycloak.tokenParsed?.preferred_username}</span>
          <Button 
            variant="outline-light" 
            size="sm"
            onClick={() => keycloak.logout({ redirectUri: window.location.origin })}
          >
            Logout
          </Button>
        </div>
      </nav>

      <Row className="mb-4">
        <Col>
          <Button 
            variant="primary" 
            size="lg"
            className="d-flex align-items-center gap-2"
            onClick={() => setShowCreateModal(true)}
          >
            <FaPlus /> Create New Whiteboard
          </Button>
        </Col>
      </Row>

      <Row xs={1} md={2} lg={3} className="g-4">
        {whiteboards.map(board => (
          <Col key={board.id}>
            <Card className="h-100 shadow-sm">
              <Card.Body>
                <Card.Title>{board.title}</Card.Title>
                <Card.Text>
                  Created: {new Date(board.created_at).toLocaleDateString()}
                </Card.Text>
                <div className="d-flex gap-2">
                  <Button 
                    variant="primary" 
                    size="sm"
                    onClick={() => handleEditBoard(board.id)}
                  >
                    <FaPencilAlt /> Edit
                  </Button>
                  <Button 
                    variant="success" 
                    size="sm"
                    onClick={() => handleExportBoard(board.id)}
                  >
                    <FaDownload /> Export
                  </Button>
                  <Button 
                    variant="danger" 
                    size="sm"
                    onClick={() => handleDeleteBoard(board.id)}
                  >
                    <FaTrash /> Delete
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      {/* Create Whiteboard Modal */}
      {showCreateModal && (
        <div className="modal show d-block" tabIndex={-1}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Create New Whiteboard</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={() => setShowCreateModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter board title"
                  value={newBoardTitle}
                  onChange={(e) => setNewBoardTitle(e.target.value)}
                />
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowCreateModal(false)}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={createWhiteboard}>
                  Create
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="modal show d-block" tabIndex={-1}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Confirm Delete</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={() => setShowDeleteModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete this whiteboard? This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </Button>
                <Button variant="danger" onClick={confirmDeleteBoard}>
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}

export default App;




